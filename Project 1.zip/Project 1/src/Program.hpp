#include <iostream>
using namespace std;

class Program {
    public:
        void start();
};