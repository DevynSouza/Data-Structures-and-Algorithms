enum vehicleType{ 
    suv = 0,
    sedan = 1,
    exotic = 2
};

 