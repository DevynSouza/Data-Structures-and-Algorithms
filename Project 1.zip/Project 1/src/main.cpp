#include <iostream>
#include "Program.hpp"
using namespace std;


int main(void) {
    Program start;
    start.start();

    return 0;
}