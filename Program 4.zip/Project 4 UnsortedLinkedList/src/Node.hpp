#ifndef Node_hpp
#define Node_hpp

#include "Item.hpp"

struct Node{
    Item data; 
    Node* next; 
};

#endif
