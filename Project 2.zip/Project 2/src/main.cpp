#include <iostream>
#include "Game.hpp"

using namespace std;

int main(void) {
    Game start;
    
    start.begin();

    return 0;
}
