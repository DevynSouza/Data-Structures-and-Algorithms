#ifndef Game_cpp
#define Game_cpp

#include "PayoutTable.hpp"
#include "SlotMachine.hpp"

#include <iostream>
#include <vector>
using namespace std;


class Game {

    public:
        
        void begin();

    private:

};

#endif