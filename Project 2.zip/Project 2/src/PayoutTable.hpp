#ifndef PayoutTable_hpp
#define PayoutTable_hpp

#include <iostream>
using namespace std;

class PayoutTable {
    public:
        int Payout(char result);

};

#endif