#pragma once
#include <iostream>
#include "CommandManager.hpp"
#include "BattleMoveFactory.hpp"
using namespace std;

class Game {
    public: 
        void Begin();


};