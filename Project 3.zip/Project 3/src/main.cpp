#include <iostream>
#include "Game.hpp"

int main (void) {
    Game start;
    start.Begin();
}