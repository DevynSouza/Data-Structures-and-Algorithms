#pragma once
enum MoveType {
      Spell = 0,
      Curse = 1, 
      Sword = 2,
      Melee =3
  };
enum ActorType {
      Ghost= 0,
      Knight = 1
  };